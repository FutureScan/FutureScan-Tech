'use client';

import { ReactNode } from 'react';
import { WalletProvider } from './WalletProvider';

export function ClientLayout({ children }: { children: ReactNode }) {
  return (
    <WalletProvider>
      {children}
    </WalletProvider>
  );
}
